
public class Testss {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String test = "1,6764";
		int index1 = test.indexOf(',');
		System.out.println(test.substring(0,index1));
		System.out.println(test.substring(index1));
		System.out.println(index1);

	}

}
