package Graphic;

import java.util.List;

public interface IRenderableHolder {
	public List<IRenderableObject> getSortedRenderableObject();
}
