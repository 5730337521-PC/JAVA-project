package Logic;

public interface IGameLogic {
	public void onStart();
	public void logicUpdate();
	public void onExit();
}
